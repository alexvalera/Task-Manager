package taskManager.display; 

public interface DisplayFile
{
	
}
