package taskManager.filter; 

public interface DashboardFilter
{
	public boolean check(String filter); 
}